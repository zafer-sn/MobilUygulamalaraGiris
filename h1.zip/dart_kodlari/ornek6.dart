void main() {
  var giris_yapildimi = true;

  if (giris_yapildimi == true) {
    print("Giriş yapıldımı değeri falsetır.");
  } else {
    print("Giriş yapıldımı değeri truedır.");
  }
}
