void main() {
  var giris_yapildimi = true; // bool giris_yapildimi = true;
  var not = 75;
  /*
   = işareti atama operatörü olarak kullanılırken 
   == işareti matematiksel eşitlik olarak kullanılır
  */
  if (giris_yapildimi == true) {
    print("Giriş yapıldımı değeri doğrudur.");
  }
/*
> işareti değerin daha büyük olması durumunda kullanılır
< işareeti değerin daha küçük olması durumunda kullanılır
>= işareti değerin daha büyük veya eşit olması durumunda kullanılır
<= işareti değerin daha küçük veya eşit olması durumunda kullanılır
!= işareti değerin eşit olmaması durumunda kullanılır.
*/
  if (not > 80) {
    print("Geçtiniz");
  }
}
