void main() {
  /* 
  değişken isimlendirme kuralları:
  1 - Değişken adı sayıyla başlayamaz. Örnek String 2isim = "Zafer"; (ama sayıyla bitebilir)
  2 - Değişken adında özel karakter kullanılamaz. Örnek String isi!m = "Zafer"; (_ hariç)
  3 - Değişken adında Türkçe karakter kullanmıyoruz. Örnek String çiçek = "Zafer";
  4 - Değişken adları büyük-küçük hard duyarlıdır.
  Örnek:
  String DEneME = "Zafer";
  String deneme = "test";
  print(deneme);
  print(DEneME);  
  */
  String isim = "Zafer";
  String sayi = "21"; // Bu da bir stringtir.
  int yas = 25;
  double kilo = 65.8;
  bool girisYapildimi = false;
  /* 
  camelCase -> int birinciSayininDegeri = 21;
  PascalCase -> int BirinciSayininDegeri = 21;
  snake_case -> int birinci_sayinin_degeri = 21;
  */
  print("İsminiz sudur:" + yas.toString());
  print(sayi);
  print(yas);
  print(kilo);
  print(girisYapildimi);
}
