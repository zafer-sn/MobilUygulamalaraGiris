void main() {
  String isim = "Zafer";
  int yas = 20;
  double boy = 1.8;
  bool giris_yapildimi = true;

  print("Senin ismin = $isim Senin yasin = $yas");
}
