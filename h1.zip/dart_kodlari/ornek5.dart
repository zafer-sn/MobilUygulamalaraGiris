void main() {
  var not = 90;
  if (not >= 90) {
    not = 55;
    if (not > 90) {
      print("90 dan büyük veya eşit");
    }
  }

  if (not > 80) {
    print("80 den büyük");
  }
}
