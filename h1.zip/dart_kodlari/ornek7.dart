void main() {
  var not = 80;
  if (not > 50) {
    print("AA aldınız.");
  } else if (not > 75) {
    print("BB aldınız.");
  } else {
    print("FF aldınız.");
  }
}
