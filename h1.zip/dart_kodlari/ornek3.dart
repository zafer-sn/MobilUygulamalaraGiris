void main() {
  var yas = 5;
  var isim = "Zafer";
  var giris_yapildimi = true;
  var boy = 1.56;

  print("yaşınıız = $yas");
}
