import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: ornek1()));
}

class ornek1 extends StatelessWidget {
  const ornek1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Başlık"),
        ),
        body: Center(
          child: ElevatedButton(
              onPressed: () {
                var a = 5;
                var uyari = AlertDialog(
                  title: Text("Başlık"),
                  content: Text("Uyari aldınız"),
                );
                showDialog(
                  context: context,
                  builder: (context) => uyari,
                );
              },
              child: Text("Tıkla")),
        ));
  }
}
