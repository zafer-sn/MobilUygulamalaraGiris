import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text("Başlık"),
        backgroundColor: Colors.grey,
      ),
      body: Center(
        child: Text(
          "Zafer",
          style: TextStyle(fontSize: 30),
        ),
      ),
    ),
  ));
}
