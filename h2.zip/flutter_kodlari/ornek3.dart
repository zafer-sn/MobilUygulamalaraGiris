import 'package:flutter/material.dart';

void main() {
  int yas = 55;
  runApp(MaterialApp(
    home: Scaffold(
      appBar: AppBar(
        title: Text("BAŞLIK"),
      ),
      body: Center(
        child: Text(
          "Yaşınız $yas",
          style: TextStyle(fontSize: 60),
        ),
      ),
    ),
  ));
}
