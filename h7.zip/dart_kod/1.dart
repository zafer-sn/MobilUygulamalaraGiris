void main() {
  String isim = "Ogrenci";
  int yas = 20;
  double boy = 1.70;
  bool gectimi = true;
  for (var i = 0; i < 2; i++) {
    if (i == 0) {
      print("${isim} ${yas} yaşa ve {boy}'a sahiptir");
    } else {
      print("${isim} {yas}'a sahip ve ders durumu: ${gectimi}'dur");
    }
  }
}
