import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AraSinav(),
  ));
}

class AraSinav extends StatelessWidget {
  const AraSinav({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("UYGULAMA"),
          backgroundColor: Colors.blue,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "Merhaba MUG Dersi",
              style: TextStyle(fontSize: 25),
            ),
            Container(
              width: 5,
              height: 5,
              color: Colors.grey[200],
              child: Center(
                child: Text("CONTAINER"),
              ),
              margin: EdgeInsets.all(50),
            ),
            ElevatedButton(onPressed: () {}, child: Text("TIKLA"))
          ],
        ));
  }
}
