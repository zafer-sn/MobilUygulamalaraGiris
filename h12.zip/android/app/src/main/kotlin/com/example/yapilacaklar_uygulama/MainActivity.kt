package com.example.yapilacaklar_uygulama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
