import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class YapilacaklarSablon extends StatelessWidget {
  String yapilacak_is;
  bool yapilacak_is_bittimi;
  Function(bool?)? is_fonksiyon;
  Function(BuildContext)? silmeFonksiyonu;

  YapilacaklarSablon(
      {super.key,
      required this.yapilacak_is,
      required this.yapilacak_is_bittimi,
      required this.is_fonksiyon,
      required this.silmeFonksiyonu});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 24, right: 24, top: 24),
      child: Slidable(
        endActionPane: ActionPane(motion: StretchMotion(), children: [
          SlidableAction(
            onPressed: silmeFonksiyonu,
            icon: Icons.delete,
            backgroundColor: Colors.red,
            borderRadius: BorderRadius.circular(12.0),
          )
        ]),
        child: Container(
          padding: EdgeInsets.all(24.0),
          child: Row(
            children: [
              Checkbox(value: yapilacak_is_bittimi, onChanged: is_fonksiyon),
              Text(
                yapilacak_is,
                style: TextStyle(
                    decoration: yapilacak_is_bittimi
                        ? TextDecoration.lineThrough
                        : TextDecoration.none),
              ),
            ],
          ),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24.0), color: Colors.yellow),
        ),
      ),
    );
  }
}
