import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class Butonum extends StatelessWidget {
  VoidCallback onpressed;
  String yazi;
  Color renk;

  Butonum(
      {super.key,
      required this.onpressed,
      required this.yazi,
      required this.renk});

  @override
  Widget build(BuildContext context) {
    return MaterialButton(color: renk, child: Text(yazi), onPressed: onpressed);
  }
}
