import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:yapilacaklar_uygulama/Uyari.dart';
import 'package:yapilacaklar_uygulama/YapilacaklarSablon.dart';
import 'package:yapilacaklar_uygulama/veritabani.dart';

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  var _box = Hive.box("MUGUygulama");
  var controller = TextEditingController();
  YapilacaklarVeritabani yv = YapilacaklarVeritabani();

  void deger_degistimi(bool? deger, int index) {
    setState(() {
      yv.yapilacak_isler[index][1] = !yv.yapilacak_isler[index][1];
    });
    yv.VerileriGuncelle();
  }

  void listeye_ekle() {
    setState(() {
      yv.yapilacak_isler.add([controller.text, false]);
    });
    Navigator.pop(context);
    controller.clear();
    yv.VerileriGuncelle();
  }

  void gorev_ekle() {
    showDialog(
      context: context,
      builder: (context) {
        return Uyari(
            iptal_et_tiklandi: () {
              setState(() {
                Navigator.pop(context);
              });
            },
            kaydet_tiklandi: listeye_ekle,
            controller: controller);
      },
    );
  }

  void gorevSil(int index) {
    setState(() {
      yv.yapilacak_isler.removeAt(index);
    });
    yv.VerileriGuncelle();
  }

  @override
  void initState() {
    if (_box.get("Veriler") == null) {
      yv.BaslangicHali();
    } else {
      yv.VerileriYukle();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.yellow[200],
        appBar: AppBar(
          backgroundColor: Colors.yellow[400],
          centerTitle: true,
          title: Text("YAPILACAKLAR"),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: gorev_ekle,
          child: Icon(Icons.add),
          backgroundColor: Colors.yellow,
        ),
        body: ListView.builder(
          itemCount: yv.yapilacak_isler.length,
          itemBuilder: (context, index) {
            return YapilacaklarSablon(
              yapilacak_is: yv.yapilacak_isler[index][0],
              yapilacak_is_bittimi: yv.yapilacak_isler[index][1],
              is_fonksiyon: (value) => deger_degistimi(value, index),
              silmeFonksiyonu: (context) => gorevSil(index),
            );
          },
        ));
  }
}
