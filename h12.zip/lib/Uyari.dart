import 'package:flutter/material.dart';
import 'package:yapilacaklar_uygulama/Butonum.dart';

class Uyari extends StatelessWidget {
  VoidCallback iptal_et_tiklandi;
  VoidCallback kaydet_tiklandi;
  var controller;

  Uyari(
      {super.key,
      required this.iptal_et_tiklandi,
      required this.kaydet_tiklandi,
      required this.controller});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.yellow[300],
      content: Container(
        height: 150.0,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(
                  labelText: "Görev ekleyin", border: OutlineInputBorder()),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Butonum(
                    renk: Colors.yellow,
                    onpressed: kaydet_tiklandi,
                    yazi: "Kaydet"),
                SizedBox(
                  width: 10.0,
                ),
                Butonum(
                    renk: Colors.yellow,
                    onpressed: iptal_et_tiklandi,
                    yazi: "İptal Et")
              ],
            )
          ],
        ),
      ),
    );
  }
}
