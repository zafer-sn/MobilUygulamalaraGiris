import 'package:hive_flutter/hive_flutter.dart';

class YapilacaklarVeritabani {
  List yapilacak_isler = [];
  var _box = Hive.box("MUGUygulama");

  // Uygulama ilk yüklendiğinde ilk çalıştığı zaman
  void BaslangicHali() {
    yapilacak_isler = [
      ["Müzik Dinle", false],
      ["Resim Yap", true]
    ];
  }

  void VerileriYukle() {
    yapilacak_isler = _box.get("Veriler");
  }

  void VerileriGuncelle() {
    _box.put("Veriler", yapilacak_isler);
  }
}
