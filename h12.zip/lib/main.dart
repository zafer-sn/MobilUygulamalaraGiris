import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:yapilacaklar_uygulama/AnaSayfa.dart';

void main() async {
  await Hive.initFlutter();
  var box = await Hive.openBox("MUGUygulama");
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
    theme: ThemeData(primarySwatch: Colors.yellow),
  ));
}
