import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
  ));
}

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  var urlTxtCont = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            TextField(
              controller: urlTxtCont,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Lütfen URL giriniz.."),
            ),
            SizedBox(
              height: 30,
            ),
            ElevatedButton(
                onPressed: () {
                  setState(() {
                    launchUrl(Uri.parse(urlTxtCont.text));
                    // launch(urlTxtCont.text);
                  });
                },
                child: Text("AÇ"))
          ],
        ),
      )),
    );
  }
}
