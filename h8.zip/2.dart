import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
  ));
}

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});
  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  var renk = [
    Colors.blue,
    Colors.red,
    Colors.yellow,
    Colors.green,
    Colors.purple
  ];
  var sayac = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("UYGULAMA"),
          backgroundColor: renk[sayac],
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "$sayac",
                style: TextStyle(color: renk[sayac], fontSize: 30),
              ),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      if (sayac == 4) {
                        sayac = 0;
                      }
                      sayac += 1;
                    });
                  },
                  child: Text("Renk Değiştir"))
            ],
          ),
        ));
  }
}
