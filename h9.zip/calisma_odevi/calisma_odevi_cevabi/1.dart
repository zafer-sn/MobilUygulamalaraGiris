import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
  ));
}

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  var vize_txt_controller = TextEditingController();
  var final_txt_controller = TextEditingController();
  var not_durum_renk = Colors.white;
  var arka_plan_renk = Colors.white;
  var gecme_durumu = "";
  double slider_degeri = 0;
  double gorunurluk = 0;
  String genel_not_ortalamasi = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Not Hesapla"),
        backgroundColor: Colors.purple[100],
      ),
      body: Container(
        color: arka_plan_renk,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.all(10),
                child: TextField(
                  controller: vize_txt_controller,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Vize notunuzu giriniz.."),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(10),
                child: TextField(
                  controller: final_txt_controller,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Final notunuzu giriniz.."),
                ),
              ),
              ElevatedButton(
                  onPressed: () {
                    setState(() {
                      var g_n_o = double.parse(vize_txt_controller.text) * 0.4 +
                          double.parse(final_txt_controller.text) * 0.6;
                      genel_not_ortalamasi = g_n_o.toString();
                      gorunurluk = 1;
                      if (g_n_o >= 45 &&
                          double.parse(final_txt_controller.text) >= 50) {
                        gecme_durumu = "GEÇTİ";
                        not_durum_renk = Colors.green;
                      } else {
                        gecme_durumu = "KALDI";
                        not_durum_renk = Colors.red;
                      }
                    });
                  },
                  child: Text("Hesapla")),
              Opacity(
                opacity: gorunurluk,
                child: Text(
                  "Not ortalamasi: $genel_not_ortalamasi \nGecme durumu: $gecme_durumu",
                  style: TextStyle(
                    fontSize: 24,
                    color: not_durum_renk,
                  ),
                ),
              ),
              DropdownMenu(
                  onSelected: (value) {
                    setState(() {
                      if (value != null) {
                        arka_plan_renk = value;
                      }
                    });
                  },
                  dropdownMenuEntries: [
                    DropdownMenuEntry(value: Colors.red, label: "Kirmizi"),
                    DropdownMenuEntry(value: Colors.green, label: "Yesil"),
                    DropdownMenuEntry(value: Colors.blue, label: "Mavi"),
                    DropdownMenuEntry(value: Colors.white, label: "Beyaz"),
                  ]),
              Slider(
                label: slider_degeri.toString(),
                value: slider_degeri,
                max: 100,
                divisions: 100,
                onChanged: (value) {
                  setState(() {
                    slider_degeri = value;
                  });
                },
              ),
              Opacity(
                opacity: slider_degeri / 100,
                child: Image(
                  image: AssetImage(
                    "images/bseu.png",
                  ),
                  height: 250,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
