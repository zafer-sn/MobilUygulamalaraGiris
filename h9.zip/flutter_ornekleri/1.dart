import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
  ));
}

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  Color container_rengi = Colors.purple;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Dropdown"),
      ),
      body: Container(
        color: container_rengi,
        /* DropdownMenu widgetı Center widgetı ile sarmalanarak
        tüm arka plan rengi değiştilebilir. */
        child: DropdownMenu(
            onSelected: (value) {
              setState(() {
                if (value != null) {
                  container_rengi = value;
                }
              });
            },
            dropdownMenuEntries: [
              DropdownMenuEntry(value: Colors.red, label: "Kirmizi"),
              DropdownMenuEntry(value: Colors.blue, label: "Mavi"),
              DropdownMenuEntry(value: Colors.green, label: "Yesil"),
              DropdownMenuEntry(value: Colors.white, label: "Beyaz")
            ]),
      ),
    );
  }
}
