import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AnaSayfa(),
  ));
}

class AnaSayfa extends StatefulWidget {
  const AnaSayfa({super.key});

  @override
  State<AnaSayfa> createState() => _AnaSayfaState();
}

class _AnaSayfaState extends State<AnaSayfa> {
  var slider_degeri = 0.0;
  var slider_max_degeri = 100.0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Slider Ornegi"),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Slider(
          label: slider_degeri.toString(),
          value: slider_degeri,
          max: slider_max_degeri,
          divisions: 20,
          onChanged: (value) {
            setState(() {
              slider_degeri = value;
            });
          },
        ),
      ),
    );
  }
}
