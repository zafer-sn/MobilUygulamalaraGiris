void main() {
  String deger;
  deger = fonksiyon_ornek("Zafer", "SERİN");
  print(deger);
}

// Değer döndüren ve parametre alan fonksiyon
String degervarparametrevar(bool kontrol1, int sayi1, double sayi2) {
  return "${kontrol1} + sayi1 + ${sayi2}";
}

// Değer döndürmeyen(void olması) ve parametre almayan(yaylı parantezlerin boş olması) fonksiyon
void degerveparametreyok() {
  print(1 * 2);
  print(11 * 25);
}

// Değer döndüren ve parametre almayan fonksiyon
int degervarparametreyok() {
  print(1 * 2);
  print(11 * 25);
  return 5 * 3;
}

// Değer döndürmeyen ve parametre alan fonksiyon
void degeryokparametrevar(int sayi1, int sayi2) {
  print(sayi1 * sayi2);
}

String fonksiyon_ornek(String isim, String soyisim) {
  return "$isim  $soyisim";
}
