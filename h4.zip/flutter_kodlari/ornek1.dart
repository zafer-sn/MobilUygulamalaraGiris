import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

void main() {
  runApp(MaterialApp(
    theme: ThemeData.light(),
    debugShowCheckedModeBanner: false,
    home: sayfa1(),
  ));
}

class sayfa1 extends StatelessWidget {
  const sayfa1({super.key});

  @override
  Widget build(BuildContext context) {
    var ogrenciler = [
      "Yiğit",
      "Ensar",
      "Alara",
      "Yusuf",
      "Enes",
      "Hakan",
      "Emirhan",
      "Sudenaz",
      "Hamza",
    ];
    return Scaffold(
        appBar: AppBar(
          title: Text("Başlık"),
          backgroundColor: Colors.indigo,
        ),
        body: Column(
          children: [
            Text("Deneme"),
            Text(
              "Test",
              style: TextStyle(fontSize: 25),
            ),
            Expanded(
                child: ListView.builder(
              itemCount: ogrenciler.length,
              itemBuilder: (context, index) {
                return Text(
                  ogrenciler[index],
                  style: TextStyle(fontSize: 40),
                );
              },
            )),
            Center(
              child: Text(
                "Gövde",
                style: TextStyle(fontSize: 40.0, color: Colors.cyanAccent),
              ),
            ),
          ],
        ));
  }
}
