import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: ornek2()));
}

class ornek2 extends StatelessWidget {
  const ornek2({super.key});

  @override
  Widget build(BuildContext context) {
    // Hazır pek çok özelliği kullanabilmek için Scaffold kullandık
    return Scaffold(
        // Scaffoldun AppBar widgetı ile üst menü oluşturduk
        appBar: AppBar(
          // Üst menünün(AppBar'ın) başlığını merkeze aldık
          centerTitle: true,
          // AppBar başlığına "BAŞLIK" yazdırdık, rengini kırmızı yaptık, font büyüklüğünü 30 yaptık ve kalın(bold) yazılmasını sağladık.
          title: Text(
            "BAŞLIK",
            style: TextStyle(
                color: Colors.red, fontSize: 30.0, fontWeight: FontWeight.bold),
          ),
          // AppBar'ın arkaplan rengini yeşil yaptık.
          backgroundColor: Colors.green,
        ),
        /* Scaffold'un body(gövde) sinde bir tane Container widgetı oluşturduk, Container'a amber rengini verdik
        Containerın child özelliğine Text widgeti verdik. Container'ın barındırdığı child widget(Text) in Containerın
        kendi sınırlarına olan uzaklığını belirlemek için padding kullandık.
        Container'ın diğer widgetlara ve ekran sınırlarına olan uzaklığını belirlemek için margin kullandık.*/
        body: Container(
          color: Colors.amber,
          child: Text("Selam"),
          /*
          EdgeInsets.all(35) -> her taraftan 35 birim boşluk bırakır.
          EdgeInsets.zero -> Hiç boşluk bırakmaz
          EdgeInsets.fromLTRB(15, 25, 35, 45) -> Soldan 15, üstten 25, sağdan 35 ve alttan 45 birim boşluk bırakır
          EdgeInsets.only(left: 35) -> sadece soldan 35 birim boşluk bırakır
          EdgeInsets.only(right: 35) -> sadece sağdan 35 birim boşluk bırakır
          EdgeInsets.only(top: 35) -> sadece üstten 35 birim boşluk bırakır
          EdgeInsets.only(bottom: 35) -> sadece aşağıdan 35 birim boşluk bırakır
          EdgeInsets.symmetric(vertical: 25, horizontal: 55) -> dikeyde(aşağıdan ve yukarıdan) eşit 25 birim boşluk bırakır
                                                                yatayda(sağdan ve soldan) eşit 55 birim boşluk bırakır.
          Burada kullanılan EdgeInsets kodları padding ve margin için aynı şekilde kullanılmasına karşın, meydana getirecekleri
          boşluklar padding ve margin kurallarına göre olacaktır.*/
          padding: EdgeInsets.all(35),
          margin: EdgeInsets.all(50),
        ));
  }
}
