import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: ornek1(),
  ));
}

class ornek1 extends StatelessWidget {
  const ornek1({super.key});

  @override
  Widget build(BuildContext context) {
    /* Doğrudan bir Container widgetı çağrılırsa bu tüm ekranı kaplayacaktır.
    Bu durumda tüm ekran kırmızı olur ve bu Containera genişlik(width) ve yükseklik(height)
    verilmesi bir anlam ifade etmez. Bunun için Container'ın Center veya farklı bir widgetla sarmalanması(wrap) gerekir.
    Şu şekilde:
    return Center(
      child: Container(
        color: Colors.red,
        width: 250,
        height: 250,
      ),
    );    
    */
    return Container(
      color: Colors.red,
      width: 250,
      height: 250,
    );
  }
}
