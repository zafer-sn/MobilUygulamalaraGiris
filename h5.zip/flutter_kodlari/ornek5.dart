import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: ornek5(),
  ));
}

class ornek5 extends StatelessWidget {
  const ornek5({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("BAŞLIK"),
        ),
        body: Column(
          children: [
            /* Sütunun(Column) 1. elemanı olarak bir Image widgetı kullanılmıştır. Bu widget resim eklemek için kullanılır.
            AssetImage klasörden bir resim yüklemeyi sağlarken, NetworkImage bir url ile resim yüklemeyi sağlar.
            AssetImage kullanılacak ise bunun pubspec.yaml dosyasına dahil edilmesi gerektiği unutulmamalıdıır.
            */
            Image(
              image: AssetImage("resimler/resim1.jpg"),
              width: 350,
            ),
            Text("Bu bir manzara resmidir"),
            Image(
                image: NetworkImage(
                    "https://media.istockphoto.com/id/1297349747/tr/foto%C4%9Fraf/t%C3%BCrkiyede-botan-kanyonu-%C3%BCzerinde-u%C3%A7an-s%C4%B1cak-hava-balonlar%C4%B1.jpg?s=612x612&w=0&k=20&c=cB1OwAy1ndPfcjp_Mt7n0rLub2hiSzgMj-qBXHSrprU="))
          ],
        ));
  }
}
