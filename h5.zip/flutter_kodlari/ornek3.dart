import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: ornek3()));
}

class ornek3 extends StatelessWidget {
  const ornek3({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BAŞLIK"),
      ),
      /* Scaffold'un gövdesinde(body) 1 tane sütun(Column) widgetı oluşturuldu.
      Column özelliği gereği tek bir widget(child özelliği) yerine birden çok widget (children özelliği)
      barındırabilmektedir. Sütun(Column) widgetı içerisinde toplam 5 adet widget bulunmaktadır.
      Bu 5 widget: 1.Container, 2.Container, Text, ElevatedButton ve 3. Container'dır.
      Column elemanlarının bir liste şeklinde [] arasına yazıldığına dikkat edilmelidir.
      Not: Burada Column yerine ListView widgetı kullanılsaydı container veya diğer widgetlar bir taşma(overflow) yani
      ekrana sığmama meydana getirseydi scroll yaparak(aşağı kakydırarak) bunların sığması sağlanırdı.
      */
      body: Column(
        children: [
          // 1. Containerın rengi kahverengi yapılmış ve 200 genişliğe(width) ve 200 yüksekliği(height) sahip olarak ayarlanmıştır.
          Container(
            color: Colors.brown,
            width: 200,
            height: 200,
          ),
          // 2. Containerın rengi cyan yapılmış ve 100 genişliğe(width) ve 100 yüksekliği(height) sahip olarak ayarlanmıştır.
          Container(
            color: Colors.cyan,
            width: 100,
            height: 100,
          ),
          // Sütunda(Column) 3. eleman olarak bir Text widgetı kullanılmış ve "Selam" yazılmıştır.
          Text("Selam"),
          /* Sütunda(Column) 4. eleman olarak bir buton(ElevatedButton) widgetı kullanılmıştır.
          Butona tıklandığı anda onPressed(){} fonksiyonu çağrılacaktır. Şu anda içi boştur(() parametreleri
          ve {} de tıklandığında yapılacakları belirtir. Butonun içerisinde child özelliği ile bir Text widgetı çağrılmıştır.
          Bu sayede butonun üstünde "TIKLA" yazmaktadır.) */
          ElevatedButton(onPressed: () {}, child: Text("TIKLA")),
          // 3. Containerın(5. Column elemanı) rengi kırmızı yapılmış ve 200 genişliğe(width) ve 800 yüksekliği(height) sahip olarak ayarlanmıştır.
          Container(
            color: Colors.red,
            width: 200,
            height: 800,
          )
        ],
      ),
    );
  }
}
