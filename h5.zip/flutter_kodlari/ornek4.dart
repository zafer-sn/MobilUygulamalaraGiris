import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: ornek4(),
  ));
}

class ornek4 extends StatelessWidget {
  const ornek4({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BAŞLIK"),
      ),
      /* Scaffold'un gövdesinde(body) bir Row(satır) widgetı oluşturduk.
      Row widgetı Column gibi children özelliği ile birden çok widgetı tutabilir.
      Burada Row'un elemanları(widgetları) yatayda tuttuğu ve tüm satırı kapladığı,
      Column'ın ise elemanları(widgetları) dikeyde tuttuğu ve tüm sütunu kapladığı unutulmamalıdır!
      Row için mainAxisAlignment yatayda hizalamayı ve crossAxisAlignment ise dikeyde hizalamayı ifade eder.
      Column için mainAxisAlignment dikeyde hizalamayı ve crossAxisAlignment ise yatayda hizalamayı ifade eder.
      MainAxisAlignment.center -> Row ve Column a göre merkeze hizalama sağlar.
      MainAxisAlignment.start -> Row ve Column a göre başlangıca hizalama sağlar. Varsayılan budur.
      MainAxisAlignment.end -> Row ve Column a göre sona hizalama sağlar.
      MainAxisAlignment.spaceBetween -> Row ve Column a ilk elemanı en başa son elemanı en sona ve aradaki elemanları da eşit boşluklar ile hizalar.
      MainAxisAlignment.spaceEvenly -> Row ve Column a göre tüm elemanların arasını eşit mesafe ile hizalar(baştan ve sondan da eşit mesafe bırakır.).
      MainAxisAlignment.spaceAround -> Row ve Column a göre baştan ve sondan eşit boşluk bırakırken aradaki elemanlarda eşit ama baştan ve sondan eşit olmayacak şekilde hizalar.
      */
      body: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: 150,
            height: 250,
            color: Colors.green,
          ),
          Text("Selam"),
          ElevatedButton(onPressed: () {}, child: Text("TIKLA"))
        ],
      ),
    );
  }
}
