import 'package:flutter/material.dart';

class Sayfa3 extends StatelessWidget {
  const Sayfa3({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          leading: Icon(Icons.ac_unit),
          title: Text("BAŞLIK"),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              "Selam",
              style: TextStyle(fontSize: 50),
            ),
            Container(
                width: 250,
                height: 200,
                color: Colors.red,
                child: Center(
                  child: Text("Yazı"),
                ))
          ],
        ),
        backgroundColor: Colors.purple);
  }
}
