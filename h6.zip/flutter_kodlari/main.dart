import 'package:flutter/material.dart';
import 'package:hafta6/sayfa1.dart';
import 'package:hafta6/sayfa2.dart';
import 'package:hafta6/sayfa3.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Sayfa3(),
  ));
}
