import 'package:flutter/material.dart';

class Sayfa2 extends StatelessWidget {
  const Sayfa2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("AYARLAR"),
      ),
      body: Center(
        child: Text("Burası ayarlar sayfasıdır.r"),
      ),
    );
  }
}
