import 'package:flutter/material.dart';
import 'package:hafta6/sayfa2.dart';

class Sayfa1 extends StatelessWidget {
  const Sayfa1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BAŞLIK"),
      ),
      drawer: Drawer(
        backgroundColor: Colors.blue[100],
        child: Column(
          children: [
            DrawerHeader(
                child: Icon(
              Icons.favorite,
              size: 40,
            )),
            ListTile(
              leading: Icon(Icons.home),
              title: Text("Ana sayfa"),
              subtitle: Text("Ana sayfaya gider"),
              trailing: Text("deneme"),
              onTap: () {},
              hoverColor: Colors.black,
              shape:
                  CircleBorder(side: BorderSide(color: Colors.red, width: 5)),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text("Ayarlar"),
              subtitle: Text("Ayarlar sayfasına gider"),
              trailing: Text("deneme"),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Sayfa2(),
                    ));
              },
            )
          ],
        ),
      ),
    );
  }
}
