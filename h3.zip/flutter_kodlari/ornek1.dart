import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: ornek1()));
}

class ornek1 extends StatelessWidget {
  const ornek1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Başlık"),
      ),
      body: Center(
        child: ElevatedButton(
            onPressed: () {
              var not = 35;
              var deger = "";
              if (not > 50) {
                deger = "Geçti";
              } else {
                deger = "Kaldı";
              }
              var uyari = AlertDialog(
                title: Text("Başlık"),
                content: Text("$deger"),
              );
              showDialog(
                context: context,
                builder: (context) => uyari,
              );
            },
            child: Text("Tıklayın")),
      ),
    );
  }
}
