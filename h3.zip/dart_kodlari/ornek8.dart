void main() {
  for (var i = 25; i >= 0; i--) {
    print(i);
  }
}
