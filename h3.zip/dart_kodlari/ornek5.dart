void main() {
  for (var i = 0; i < 15; ++i) {
    print(i);
  }
}
