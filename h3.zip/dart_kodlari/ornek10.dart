void main() {
  var liste1 = [1, 2, 5, "selam", 6.4];
  for (var i = 0; i < liste1.length; i++) {
    print(liste1[i]);
  }
}
