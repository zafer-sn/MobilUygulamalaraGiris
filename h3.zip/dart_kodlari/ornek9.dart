void main() {
  var liste1 = ["test", 2, 4, -4, false];
  liste1.forEach((test) {
    print(test);
  });
}
