void main() {
  var i = 1; // i = 1
  var i2 = i++; // i2 = 1, i = 2
  var i3 = ++i; // i3 = 3, i = 3
  print("$i $i2 $i3");
}
