void main() {
  var liste1 = [1, 2, "test", false];
  print(liste1[3]);
}
