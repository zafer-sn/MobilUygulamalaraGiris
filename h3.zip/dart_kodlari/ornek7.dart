void main() {
  var i = 5;
  while (i < 15) {
    print(i);
    i = i + 1;
  }
}
