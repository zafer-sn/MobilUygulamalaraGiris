void main() {
  var liste1 = ["abc", 3, 5, 2.5, true, "beyza"];
  liste1.remove(5);
  liste1.clear();
  print(liste1);
}
