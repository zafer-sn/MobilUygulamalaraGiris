void main() {
  var liste = [1, 2, 3, "deneme", 5.3];
  print(liste);
}
