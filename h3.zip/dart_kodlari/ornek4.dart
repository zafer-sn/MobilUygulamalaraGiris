void main() {
  // for döngüsü
  /*for(baslangic_degeri; şart; değişim_miktarı)
  {

  }*/
  for (var i = 5; i < 15; i++) {
    print(i);
  }
}
